//
//  NTViewController.h
//  TableView
//
//  Created by MD101 on 14-10-9.
//  Copyright (c) 2014年 NT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactViewController : UIViewController<UIAlertViewDelegate>

@end
