//
//  newTabBarViewController.h
//  Login
//
//  Created by 常柯 on 15/12/15.
//  Copyright © 2015年 menuz's lab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapViewController.h"
#import "ContactViewController.h"
#import "settingViewController.h"

@interface newTabBarViewController : UITabBarController


@end
