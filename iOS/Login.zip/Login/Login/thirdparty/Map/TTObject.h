//
//  TTObject.h
//tt这两个   appdelegate.m    carimageviewcontroller.m


#import <Foundation/Foundation.h>


@interface TTObject : NSObject

- (void)startTimer;
- (void)stopTimer;

@end
