//
//  NTTableViewController.h
//  TableView
//
//  Created by MD101 on 14-10-10.
//  Copyright (c) 2014年 NT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTTableViewController : UITableViewController

@end
