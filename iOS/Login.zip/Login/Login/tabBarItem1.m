//
//  tabBarItem1.m
//  Login
//
//  Created by 常柯 on 15/12/23.
//  Copyright © 2015年 menuz's lab. All rights reserved.
//

#import "tabBarItem1.h"

@implementation tabBarItem1
-(void)viewDidLoad{
    [self.image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [self setImage:[UIImage imageNamed:@"123"]];
}
@end
