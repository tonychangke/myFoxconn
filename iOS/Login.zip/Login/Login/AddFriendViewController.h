//
//  AddFriendViewController.h
//  Login
//
//  Created by 常柯 on 15/10/5.
//  Copyright (c) 2015年 menuz's lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendViewController : UIViewController
- (IBAction)addFriend:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *friendid;
@end
