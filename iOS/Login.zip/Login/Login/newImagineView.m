//
//  newImagineView.m
//  Login
//
//  Created by 常柯 on 15/10/20.
//  Copyright (c) 2015年 menuz's lab. All rights reserved.
//

#import "newImagineView.h"

@implementation newImagineView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
