//
//  offline.h
//  BLEoffline
//
//  Created by whathexd on 15/10/2.
//  Copyright (c) 2015年 whathexd. All rights reserved.
//

#ifndef BLEoffline_offline_h
#define BLEoffline_offline_h


#endif
#define ARC4RANDOM_MAX 0X100000000

@interface OffLine : NSObject


@end