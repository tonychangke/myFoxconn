//
//  tabBarItem1.h
//  Login
//
//  Created by 常柯 on 15/12/23.
//  Copyright © 2015年 menuz's lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tabBarItem1 : UITabBarItem

@end
