//
//  TBController.h
//  Login
//
//  Created by localization on 15/9/28.
//  Copyright (c) 2015年 menuz's lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBController : UITabBarController
@property NSUInteger * index;
@end
