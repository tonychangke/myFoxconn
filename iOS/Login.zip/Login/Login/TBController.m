//
//  TBController.m
//  Login
//
//  Created by localization on 15/9/28.
//  Copyright (c) 2015年 menuz's lab. All rights reserved.
//

#import "TBController.h"

@implementation TBController

-(void)viewDidLoad
{
    //[super viewDidLoad];
    //self.index=1;
//    self.tabBarController.selectedViewController = [self.tabBarController.viewControllers objectAtIndex:1];
//    [self.tabBarController setSelectedIndex:2];
}
@end
