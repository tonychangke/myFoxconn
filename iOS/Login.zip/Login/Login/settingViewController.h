//
//  settingViewController.h
//  Login
//
//  Created by 常柯 on 15/10/30.
//  Copyright © 2015年 menuz's lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface settingViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *username;

@end
